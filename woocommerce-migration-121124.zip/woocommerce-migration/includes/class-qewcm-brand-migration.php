<?php
class QEWCM_Brand_Migration {
}