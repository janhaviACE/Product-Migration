<?php
namespace QEWCM;
use QEWCM\API\QEWCM_Variation;
use \WC_Product_Variation;
use \WC_Product_Attribute;
use \WC_Product_Variable;


class QEWCM_Variation_Migration{

	public function createWcAttribute($wc_product_id, $bigcommerceVariation){
		global $wpdb;

		// $variationResponse = new QEWCM_Variation();
		// $variation_data = $variationResponse->getProductVariationData();
		

		foreach ($bigcommerceVariation as $variant) {
			
			if(!empty($variant['option_values'])){
				foreach($variant['option_values'] as $option){
				
					$variationObj = new WC_Product_Variation();

						//foreach ($variation['option_values'] as $option) {
							
							$attribute_name = $option['option_display_name'];
					    	$option_values = explode (",", $option['label']);     	
							$attribute_slug = sanitize_title($attribute_name);

							// Check if attribute already exists
						    $attribute_exists = $wpdb->get_var($wpdb->prepare(
						        "SELECT attribute_id FROM {$wpdb->prefix}woocommerce_attribute_taxonomies WHERE attribute_name = %s",
						        $attribute_slug
						    ));


						    if (!$attribute_exists) {
						        //Insert attribute into WooCommerce attribute table
						        $wpdb->insert(
						            "{$wpdb->prefix}woocommerce_attribute_taxonomies",
						            [
						                'attribute_name' => $attribute_slug,
						                'attribute_label' => $attribute_name,
						                'attribute_type' => 'select', // Use dropdown type
						                'attribute_orderby' => 'menu_order',
						                'attribute_public' => 1,
						            ],
						            ['%s', '%s', '%s', '%s', '%d']
						        );
						        // Refresh WooCommerce's attribute cache
        						delete_transient('wc_attribute_taxonomies');
        					}
    						// Register the attribute taxonomy
						    $taxonomy_name = wc_attribute_taxonomy_name($attribute_name);
						    if (!taxonomy_exists($taxonomy_name)) {
						        register_taxonomy(
						            $taxonomy_name,
						            'product',
						            array(
						                'hierarchical' => false,
						                'label' => $attribute_label,
						                'query_var' => true,
						                'rewrite' => array('slug' => 'pa_' . $attribute_name),
						            )
						        );
						    }

						        // $attribute_id = $wpdb->insert_id;
						        // // Register the new attribute as a taxonomy
						        // wc_create_attribute([
						        //     'name' => $attribute_name,
						        //     'slug' => $attribute_slug,
						        //     'type' => 'select',
						        //     'order_by' => 'menu_order',
						        //     'has_archives' => false,
						        // ]);
						    
						    // Register terms (options) for the attribute
							$taxonomy_name = 'pa_' . $attribute_slug; // WooCommerce attribute prefix
						    // Ensure the taxonomy is registered
						    if (!taxonomy_exists($taxonomy_name)) {
						        return new WP_Error('invalid_taxonomy', 'Attribute taxonomy does not exist.');
						    }

						    // Loop through each term and add it
						    foreach ($option_values as $option_value) {
						        if (!term_exists($option_value, $taxonomy_name)) {	
						            wp_insert_term($option_value, $taxonomy_name);
						        }
						         //Store terms for each attribute in a map for later use
		                    	$attribute_terms_map[$taxonomy_name][] = $option_value;
						    }

						    // // Register terms (options) for the attribute
							// $attribute_taxonomy = 'pa_' . $attribute_slug; // WooCommerce attribute prefix
							// //echo "<pre>";print_r($option_values);echo "<pre>";exit;
							// foreach ($option_values as $option_value) {
						    //     if (!term_exists($option_value, $attribute_taxonomy)) {	
						    //         wp_insert_term($option_value, $attribute_taxonomy);
						    //     }
						    //      //Store terms for each attribute in a map for later use
		                    // 	$attribute_terms_map[$attribute_taxonomy][] = $option_value;
						    // }
						    //echo "Attribute name map";print_r($attribute_terms_map);exit;

						    // Get or create product attribute data
							$attribute = new WC_Product_Attribute();
		                    $attribute->set_id(wc_attribute_taxonomy_id_by_name($attribute_slug));
		                    $attribute->set_name($taxonomy_name);
		                    $attribute->set_options($option_values);
		                    $attribute->set_position(0);
		                    $attribute->set_visible(true);
		                    $attribute->set_variation(true); 

		                    // Assign attribute to the product
							$product = wc_get_product($wc_product_id);
							$product_attributes = $product->get_attributes();
							$product_attributes[$taxonomy_name] = $attribute;
							$product->set_attributes($product_attributes);
							$product->save();

						//}

						
					}

				}
				// Create variations based on the attribute terms combinations
    			$this->create_product_variations($wc_product_id, $attribute_terms_map,$variant);
			}
		
		
	  
	}

	// Helper function to create product variations from attribute combinations
	private function create_product_variations($wc_product_id, $attribute_terms_map,$variant) {
	    // Generate all possible combinations of terms for attributes
	    $combinations = $this->generate_combinations($attribute_terms_map);

	    // Loop through each combination and create variation
	    foreach ($combinations as $variation_attributes) {

	    	// Check if variation already exists for this combination
	        $existing_variation = $this->check_existing_variation($wc_product_id, $variation_attributes);
	      
	        if ($existing_variation) {
	            // If variation exists, skip creation
	            continue;
	        }

	       	$product = wc_get_product($wc_product_id);
	        // Add the variation if no duplicate was found
		    $variation_post = array(
		        'post_title'  => $product->get_name() . ' Variation',
		        'post_name'   => 'product-' . $wc_product_id . '-variation',
		        'post_status' => 'publish',
		        'post_parent' => $wc_product_id,
		        'post_type'   => 'product_variation',
		        'guid'        => home_url() . '/?product_variation=' . $wc_product_id,
		    );
		    $variation_id = wp_insert_post($variation_post);

	        $variation = new WC_Product_Variation($variation_id);
	        $variation->set_parent_id($wc_product_id);
	        $variation->set_status('publish'); // Set to published status
	       	$variation->set_regular_price($variant['price']); 
            //$variation->set_sku($variation_data['sku']);           
            $variation->set_stock_quantity($variant['inventory_level']); 

	         // Set attributes for each variation based on combination
	        $formatted_attributes = [];
	        foreach ($variation_attributes as $attribute_taxonomy => $term_slug) {
	            // Set attributes with correct taxonomy and term value
	            $formatted_attributes[$attribute_taxonomy] = $term_slug;
	        }

	        // Set attributes for each variation based on combination
	        $variation->set_attributes($formatted_attributes);
	        $variation->save(); // Save the variation
	    }
	}

	// Helper function to check if a variation already exists for the product and combination
	private function check_existing_variation($product_id, $variation_attributes) {
		
	    // Get all variations of the product
	    $product = wc_get_product($product_id);
	    $existing_variations = $product->get_children(); // Get all variation IDs
	   	$is_duplicate = true;

	    // Loop through existing variations and compare their attributes
	    foreach ($existing_variations as $variation_id) {
	        $variation = wc_get_product($variation_id);
	        $existing_attributes = $variation->get_attributes();

	        foreach ($variation_attributes as $key => $value) {
	            if (!isset($existing_attributes[$key]) || $existing_attributes[$key] !== $value) {
	                $is_duplicate = false;
	                break;
	            }
        	}

	        if ($is_duplicate) {
	            // Skip adding if variation already exists
	            return 'Variation already exists, skipped adding.';
	        }

		    //     // Compare attributes (adjust as needed based on how you want to compare them)
		    //     if (array_diff($variation_attributes, $existing_attributes) === [] && array_diff($existing_attributes, $variation_attributes) === []) {
		    //         return true; 
		    //     }
		    // }

		    // return false; 
		}
	}
	// Helper function to generate all possible combinations of terms for attributes
	private function generate_combinations($arrays) {
	    $result = [[]];

	    foreach ($arrays as $property => $property_values) {
	        $temp = [];
	        foreach ($result as $result_item) {
	            foreach ($property_values as $property_value) {
	                $temp[] = array_merge($result_item, [$property => $property_value]);
	            }
	        }
	        $result = $temp;

	       
	    }

	    return $result;
	}



}