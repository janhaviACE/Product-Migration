<?php
namespace QEWCM\API;
use QEWCM\Helper\QEWCM_API_Controller;

class QEWCM_Variation{
	public function getProductVariationData(){

		$apiUrl = 'http://localhost/bigCommerce_migration/api/get_product_variation.php';
		$parms = array(['method'=>'get']);    

		//Create object of MigrationHelper
		$migrationHelper = new QEWCM_API_Controller();

		// Check if the object is created successfully
		if ($migrationHelper !== null && $migrationHelper instanceof QEWCM_API_Controller) {
		    try {

		        // Call the method to execute the GET request and get the response
		        $response = $migrationHelper->getCURLData($apiUrl,$parms);
		        
		        $data = json_decode($response, true); 

		        return $data;

		    } catch (Exception $e) {              
		        echo 'Error: ' . $e->getMessage();
		    }
		}else{
		    echo 'Failed to create MigrationHelper object.';
		}

	}
}