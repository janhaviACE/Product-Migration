<?php
namespace QEWCM\API;
use QEWCM\Helper\QEWCM_API_Controller;

class QEWCM_Category{
    public $apiUrl = 'http://localhost/bigCommerce_migration/api/get_category_data.php';
    public $parms = array(['method'=>'get']); 
    
    public function getCategoryData(){
         

        $migrationHelper = new QEWCM_API_Controller(); 
   
        try {
            // Call the method to execute the GET request and get the response
            $response = $migrationHelper->getCURLData($this->apiUrl,$this->parms);
            $data = json_decode($response, true); 

                return $data;
            // echo $response;
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
         
    }
}
