<?php
namespace QEWCM\Helper;

class QEWCM_API_Controller {
    /*
    @parm curl url,$parm = array (optional)
    @return array
    */
    
    public function getCURLData($url,$parms=array()){
      
        try {

            if($url == ""){
                throw new Exception('Invalid URL.');
            }
            
            if(!empty($parms)){
                if(!is_array($parms)){
                    throw new Exception('Invalid arguments.');
                }
            }
            // Initialize a cURL session
            $curl = curl_init();
            
            // Check if cURL was successfully initialized
            if ($curl === false) {
                throw new Exception('Failed to initialize cURL');
            }
        
            // Set cURL options
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true, // Return the response as a string instead of outputting it
                CURLOPT_ENCODING => '', // Handle all encodings
                CURLOPT_MAXREDIRS => 10, // Maximum number of redirects to follow
                CURLOPT_TIMEOUT => 30, // Timeout after 30 seconds
                CURLOPT_FOLLOWLOCATION => true, // Follow any "Location" headers
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, // Use HTTP 1.1
                CURLOPT_CUSTOMREQUEST => $parms[0]['method'], // Use GET request
                CURLOPT_HTTPHEADER => array(
                    'Cookie: PHPSESSID=cgmoj3ietelvipqve6dev26nlj' // Set the session cookie
                ),
            ));
        
            // Execute the cURL request
            $response = curl_exec($curl);
        
            // Check if any errors occurred during the cURL request
            if (curl_errno($curl)) {
                throw new Exception('cURL Error: ' . curl_error($curl));
            }
        
            // Check the HTTP response code
            $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            if ($http_code !== 200) {
                throw new Exception("Unexpected HTTP code: $http_code. Response: $response");
            }
        
            return $response;
        
        } catch (Exception $e) {
            // Catch any exceptions and display the error message
            throw new Exception( 'Error: ' . $e->getMessage() );

        } finally {
            
            // Close the cURL session if it was initialized
            if (isset($curl) && is_resource($curl)) {
                curl_close($curl);
            }
            
        }
    }

    /*
    this to get all termws array
    @return array
    */
    public function termArray() {
        global $wpdb;

        // Define the meta_key you are looking for
        $meta_key = '_bigcommerce_category_id';

        // Prepare the SQL query
        $query = $wpdb->prepare( 
            "SELECT * FROM `pm_termmeta` WHERE `meta_key` = %s", 
            $meta_key 
        );

        // Execute the query and get the results as an array
        $results = $wpdb->get_results( $query, ARRAY_A );

        // Check if we have results and output them
        $categories_arr = [];
        if ( !empty($results) ) {
            foreach ( $results as $row ) {
                // Process each row here
                $categories_arr[] = array('term_id'=>$row['term_id'],'meta_value'=>$row['meta_value'],'meta_key'=>$row['meta_key']);
            }
        }

        return $categories_arr;
    }

    /*
    this to get all termws array
    @parm termarrsy with termArray() , $meta vale  (int)
    @return array
    */
    public function findTermIdByMetaValue($term_array, $meta_value) {

        foreach ($term_array as $item) {
            // Check if the 'meta_value' matches the one we're looking for
            if ($item['meta_value'] == $meta_value) {
                // Return the corresponding 'term_id'
                return $item['term_id'];
            }
        }        
        // If no match is found, return null or a message
        return null; // or you can return 'No matching term_id found'
    }
}



?>
