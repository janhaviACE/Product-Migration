<?php
namespace QEWCM;

class QEWCM_Image_Migration{
    /**
     * Custom function to sync BigCommerce product images with WordPress
     * 
     */
    function sync_bigcommerce_images_to_wordpress($bigcommerce_images_response, $existing_product_id) {
        // WordPress includes for media and file handling
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        // Check if BigCommerce product data contains images
        if (!empty($bigcommerce_images_response)) {
            $first_image = true; // To track the first image for featured image assignment

            // Find the image with the lowest sort_order
            $lowest_sort_order_image = null;
            
            // Loop through each image data
            foreach ($bigcommerce_images_response as $image_data) {
                $image_url = $image_data->url_standard; 
                $alt = $image_data->description;
                $order_by_number = $image_data->sort_order; 
                //echo "<pre>";print_r($lowest_sort_order_image);
                $is_thumbnail = $image_data->is_thumbnail;
                
                //Find the lowest sort order
                if ($lowest_sort_order_image === null || $order_by_number < $lowest_sort_order_image->sort_order) {
                    $lowest_sort_order_image = $image_data;
                }

                $image_id = $this->find_image_in_media_library($image_url);
                    
                if ($image_id) {
                    // Image already exists in the media library, so update it (if needed)
                    echo 'Image already exists, updating: ' . $image_url . '<br>';
                } else {  
                    // Download and insert the image into WordPress
                    $image_id = media_sideload_image($image_url, $existing_product_id, null, 'id');

                    if (!is_wp_error($image_id)) {
                        // Save the original image URL as meta to avoid future duplicates
                        update_post_meta($image_id, '_original_image_url', $image_url);
                        
                        echo 'Image added: ' . $image_url . '<br>';
                    } else {
                        // Handle image download errors
                        echo 'Error downloading image: ' . $image_url . '<br>';
                        continue;
                    }
                }

                

                // Assign the lowest order image as featured image  
                if (isset($lowest_sort_order_image->url_standard)) {
                    $image_url = $lowest_sort_order_image->url_standard;

                    // Download the image and attach it to the WordPress product
                    $attachment_id = media_sideload_image($image_url, $existing_product_id, null, 'id');

                    if (is_wp_error($attachment_id)) {
                        return $attachment_id; // Handle error if image download fails
                    }
                    // Set the lowest sort order as the featured image
                    set_post_thumbnail($existing_product_id, $attachment_id);
                    
                } else {
                    // Add the image to the product gallery
                    $gallery = get_post_meta($existing_product_id, '_product_image_gallery', true);
                    $gallery_ids = !empty($gallery) ? explode(',', $gallery) : array();
                    $gallery_ids[] = $image_id;
                    update_post_meta($existing_product_id, '_product_image_gallery', implode(',', $gallery_ids));
                }
            
            }
        } else {
            echo 'No images found for this BigCommerce product.';
        }
    }
    /**
     * Find an image in the WordPress media library based on the original image URL
     *
     * @param string $image_url The URL of the image to search for
     * @return int|false The attachment ID if found, or false if not found
     */
    function find_image_in_media_library($image_url) {
        global $wpdb;

        // Search in the postmeta table for any media that has the same original image URL
        $attachment_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_original_image_url' AND meta_value = %s LIMIT 1",
                esc_url_raw($image_url)
            )
        );

        return $attachment_id ? (int) $attachment_id : false;
    }

}
