<?php
namespace QEWCM;
use QEWCM\API\QEWCM_Category;

class QEWCM_Category_Migration {

	public function categoryMigration(){ 
		global $wpdb;

        $categoryResponse = new QEWCM_Category();
        $categories = $categoryResponse->getCategoryData(); 

		// $categories=json_decode($data,true); print_r($categories);exit;
        $category_map = [];
        foreach($categories as $category){

            // Check if the category already exists in WordPress by its BigCommerce ID
            $existing_category = get_term_by('meta_value', $category['bigcommerce_id'], 'product_cat');
            
            if ($existing_category) {
                // Category already exists, skip insertion
                continue;
            }
            
            if ($category['bigcommerce_parent_id'] == 0) {
                // Insert parent category
                $inserted = wp_insert_term(
                    $category['category_title'],
                    'product_cat',
                    array(
                        'description' => $category['category_description'],
                        'slug' => sanitize_title($category['category_title'])
                    )
                );

                if (!is_wp_error($inserted)) {
                    // $inserted_category_id = $inserted['term_id'];
                    // $category_map[$category['bigcommerce_id']] = $inserted_category_id; // Map BigCommerce category ID to WordPress term ID
                    // Store the mapping of BigCommerce ID to WordPress term_id
                    update_option('bc_category_' . $category['bigcommerce_id'], $inserted['term_id']);
                    // Store BigCommerce category ID in term meta
                    add_term_meta($inserted['term_id'], '_bigcommerce_category_id', $category['bigcommerce_id'], true);
                }
            } 

        }
       
        foreach($categories as $category){ 
            // Check if the category already exists in WordPress by its BigCommerce ID
            $existing_category = get_term_by('meta_value', $category['bigcommerce_id'], 'product_cat');

            if ($existing_category) {
                // Category already exists, skip insertion
                continue;
            }
            
            if ($category['bigcommerce_parent_id'] != 0) {
                // Get the parent category's term_id from WordPress
                $parentTermId = get_option('bc_category_' . $category['bigcommerce_parent_id']);

                if ($parentTermId) {
                    // Insert the child category with parent ID
                    $inserted = wp_insert_term(
                        $category['category_title'],
                        'product_cat',
                        array(
                            'description' => $category['category_description'],
                            'parent' => $parentTermId, // Set the correct parent category
                            'slug' => sanitize_title($category['category_title'])
                        )
                    );

                    if (!is_wp_error($inserted)) {
                        // $inserted_category_id = $inserted['term_id'];
                        // $category_map[$category['bigcommerce_id']] = $inserted_category_id; // Map BigCommerce category ID to WordPress term ID
                        // Store the child category mapping
                        update_option('bc_category_' . $category['bigcommerce_id'], $inserted['term_id']);
                        // Store BigCommerce category ID in term meta
                        add_term_meta($inserted['term_id'], '_bigcommerce_category_id', $category['bigcommerce_id'], true);
                    }
                }
                
            }       
        }
        //print_r($category_map);exit;
        // get_product_data();

        wp_send_json_success('Categories inserted successfully.');
	}
}
