<?php
class QEWCM_Migration {
}