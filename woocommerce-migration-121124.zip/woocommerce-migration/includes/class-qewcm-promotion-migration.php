<?php
class QEWCM_Promotion_Migration {
}