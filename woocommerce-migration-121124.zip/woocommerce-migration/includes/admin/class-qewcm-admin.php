<?php
namespace QEWCM\Admin;

use QEWCM\QEWCM_Product_Migration;

class QEWCM_Admin {

    public function add_menu_page() {
        add_menu_page(
            'WooCommerce Migration',
            'WC Migration',
            'manage_options',
            'qewcm-dashboard',
            [$this, 'qewcm_dashboard'],
            'dashicons-migrate',
            6
        );
        // Add a submenu under the main menu
        add_submenu_page(
            'qewcm-dashboard', // Parent slug
            'API Key', // Page title
            'API Key', // Menu title
            'manage_options', // Capability
            'qe-migrate', // Menu slug
            'qe_MigratePageHtml' // Function to display the settings page
        );

        // Add a submenu under the main menu
        add_submenu_page(
            'qewcm-dashboard', // Parent slug
            'Migration', // Page title
            'Migration', // Menu title
            'manage_options', // Capability
            'migration-page', // Menu slug
            'migration_page_html' // Function to display the settings page
        );
    }

    public function qewcm_dashboard() {
        echo '<div class="wrap">
            <div id="response-message"></div>
            <form action="" method="POST" id="api_key_form">
                <label>Enter the API key</label>
                <input type="text" name="api_key" id="api_key"><br><br>
                <label>Enter the store hash code</label>
                <input type="text" name="store_hash_code" id="store_hash_code"><br><br>
                <label>Select the migration platform</label>
                <select name="api_platform" id="api_platform">
                     <option value="bigcommerce">BigCommerce</option>
                    <option value="Shopify">Shopify</option>                
                </select><br>
                <input type="submit" value="Get Data">
            </form>        
        </div>';

        $qewcmProductMigration = new QEWCM_Product_Migration();
        $qewcmProductMigration->productMigration();

        
    }

    public function enqueue_admin_assets() {
        wp_enqueue_style('wcmp-admin-style', plugin_dir_url(__FILE__) . '../assets/css/admin-style.css');
        wp_enqueue_script('wcmp-admin-script', plugin_dir_url(__FILE__) . '../assets/js/ajax-script.js');       
       

        // Localize script to use Ajax URL
        wp_localize_script( 'wcmp-admin-script', 'ajax', array( 
            'ajax_url' => admin_url( 'admin-ajax.php' )
        ));
    }

    public function qe_MigratePageHtml() {
        echo "test";
            
    }
}
