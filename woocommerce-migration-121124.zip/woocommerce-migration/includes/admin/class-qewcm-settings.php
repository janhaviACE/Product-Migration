<?php
class QEWCM_Settings {
    
}
