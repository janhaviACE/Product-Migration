<?php
class QEWCM_Blog_Migration {
}