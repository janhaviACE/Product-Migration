<?php
class QEWCM_Discount_Migration {
}