<?php
use QEWCM\admin\QEWCM_Admin;

class QEWCM_Plugin {
    public function __construct() {
        $this->define_admin_hooks();
    }

    private function define_admin_hooks() {
        $admin = new QEWCM_Admin();
        
        add_action('admin_menu', [$admin, 'add_menu_page']);
        add_action('admin_enqueue_scripts', [$admin, 'enqueue_admin_assets']);
    }

    public function run() {
        // Initialize components, hooks, etc.
    }
}