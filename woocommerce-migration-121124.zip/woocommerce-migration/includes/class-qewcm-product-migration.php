<?php
namespace QEWCM;
use QEWCM\API\QEWCM_Product;
use QEWCM\API\QEWCM_Option;
use QEWCM\QEWCM_Variation_migration;
use QEWCM\QEWCM_Image_Migration;
use QEWCM\QEWCM_Category_Migration;
use QEWCM\Helper\QEWCM_API_Controller;
use \WC_Product_Attribute;
use \WC_Product_Variation;

class QEWCM_Product_Migration {

	/**
	 * Assign category to product
	 *
	 * @param int $new_product_id 
	 * @param array $categories  * 
	 */
	function assignCategoryToProduct($new_product_id,$categories)
	{ 
	    $migrationHelper = new QEWCM_API_Controller();
	    $product_id = $new_product_id; // BigCommerce product ID  
	    $term_array = $migrationHelper->termArray();
	   
	    $wp_categories = array(); // WordPress category IDs   
	    
	    // Map BigCommerce category IDs to WordPress term IDs
	    foreach ($categories as $bc_category) { //print_r($bc_category);exit;
	        $bc_category_name=$bc_category['cat_name'];
	        // Check if this category exists in WooCommerce
	        $category = get_term_by( 'name', $bc_category_name, 'product_cat' );
	        
	        if ( $category ) {
	            // If category exists, add its ID to the array
	            $existing_category_ids[] = $category->term_id;
	        }
	       
	        //$wp_categories[] = $migrationHelper->findTermIdByMetaValue($term_array,$bc_category['bc_id']);
	    }
	    
	    // Assign categories to the product in WooCommerce
	    if (!empty($existing_category_ids)) { 
	        wp_set_object_terms($product_id, $existing_category_ids, 'product_cat');
	    }
	    else{
	        echo "Failed to Assign Category";
	    }
	                
	}

	// Function to assign attributes to a WooCommerce product
	function assign_wc_product_attributes($wc_product_id, $attributes) {

		
	    // Get the product object
	    $product = wc_get_product($wc_product_id);

	     if (!$product) {
	        return; // Exit if the product is invalid
	    }

	    // Prepare the attribute data
	    $attributes_data = array();
	    $attributesArr = array();
	    $attribute_values_map = array();
	  
	  	if (!empty($attributes['option_values'])) {

		    foreach ($attributes['option_values'] as $att_option) { 
		    	
		    	
	    		$attribute_name = $attributes['display_name'];
            	$attribute_values_map[$attribute_name] = [];

            	// Define the attribute taxonomy name
            	$taxonomy = wc_attribute_taxonomy_name(sanitize_title($attribute_name));

            	// Register taxonomy if it doesn't exist
	            if (!taxonomy_exists($taxonomy)) {
	                register_taxonomy(
	                    $taxonomy,
	                    'product',
	                    array(
	                        'hierarchical' => true,
	                        'label' => ucfirst($attribute_name),
	                        'query_var' => true,
	                        'rewrite' => array('slug' => sanitize_title($attribute_name)),
	                    )
	                );
	            }
	         
	            // Assign terms to product and populate values for variations
		       
                $label = $att_option['label'];
                $option_values = explode (",", $att_option['label']);     	

                // Insert term if it doesn't exist
                if (!term_exists($label, $taxonomy)) {
                    wp_insert_term($label, $taxonomy);
                }

                // Assign term to product
                wp_set_object_terms($wc_product_id, $label, $taxonomy, true);

                // Collect values for this attribute
                $attribute_values_map[$attribute_name][] = $label;
                // print_r($attribute_values_map[$attribute_name]);
                // Create the WooCommerce attribute object
				$attribute = new WC_Product_Attribute();

				$attribute->set_name($attribute_name);
		        $attribute->set_options($option_values);
		        $attribute->set_position(0);
		        $attribute->set_visible(true);
		        $attribute->set_variation(true);

		        // Add the attribute to the array
		        $product_attributes[] = $attribute;	
		       
	            
	        }
	      	$product->set_attributes($product_attributes);		
			$product->save();
    	}		
		    	
			    
	}

	/**
     * Function to assign custom variations with price and SKU to a WooCommerce product.
     *
     * @param int   $woocommerce_product_id ID of the WooCommerce product.
     * @param array $variations             Array of variation data (attributes, price, SKU).
     */
    function assign_custom_variations_to_product($woocommerce_product_id, $variations) {
        $product = wc_get_product($woocommerce_product_id);
      
        if (!$product || $product->get_type() != 'variable') {
            return; // Return if product is not a variable product
        }
    
        $variation_ids = [];
        $variation_attributes = [];

        foreach ($variations as $variation_data) {
            // Create a variation
            $variation = new WC_Product_Variation();
      		$variation->set_parent_id($woocommerce_product_id);

            
            $variation->set_status('publish'); // Set the variation status to 'publish'

            foreach ($variation_data['option_values'] as $attribute_value) { 
            	$attribute_name = sanitize_title($attribute_value['option_display_name']);  // Sanitize attribute name 
            	$taxonomy = 'pa_' . $attribute_name; 
            	$variation_attributes[$taxonomy] = $attribute_value['label'];
            
            }

            
            $variation->set_regular_price($variation_data['price']); 
            //$variation->set_sku($variation_data['sku']);           
            $variation->set_stock_quantity($variation_data['inventory_level']); // Set stock quantity for the variation (example)
            $variation->set_attributes($variation_attributes); 
           
            // Save the variation
            $variation->save();
 
            
        }

      
    }



	/*
	* Product migration using bigcommerce data
	*
	*/
	public function productMigration(){
		global $wpdb;
		//Create object of QEWCM_GetProductResponse
		$productResponse = new QEWCM_Product();
		$data = $productResponse->getProductData();		

		// Number of items per batch
        $batch_size = 10;
      
        // Total records
        $total_records = count($data);
       
        // Start looping in batches
        for ($i = 0; $i < $total_records; $i += $batch_size) {
            // Get the current batch (slice of 10 records)
            $batch = array_slice($data, $i, $batch_size);
            
            $table_name = $wpdb->prefix . 'posts';
            $table_name_postmeta = $wpdb->prefix.'postmeta';
            // $prod_data = array();
            
            
            foreach($batch as $item){ //echo "<pre>";print_r($item);exit;
                //cho "<pre>";print_r($item);exit;
                $bigcommerce_response=json_decode($item['data']['bigcommerce_response']);
                $bigcommerce_images_response=json_decode($item['data']['bigcommerce_images_response']);             
                $bigcommerceCategories=$item['categories'];
                $bigcommerceVariation=$item['variation'];
                $bigcommerceOption=$item['attribute_option'];    
               	//echo "<pre>";print_r($bigcommerce_images_response);echo "<pre>";exit;
                $name=$bigcommerce_response->name;
                $description=$bigcommerce_response->description;
                $price=$bigcommerce_response->price;
                $sale_price=$bigcommerce_response->sale_price;
                $sku=$bigcommerce_response->sku;
                $weight=$bigcommerce_response->weight;
                $width=$bigcommerce_response->width;
                $height=$bigcommerce_response->height;
                $depth=$bigcommerce_response->depth;
                $inventory_level=$bigcommerce_response->inventory_level;
                $bigcommerce_id=$bigcommerce_response->id;
                $categories = $bigcommerce_response->categories; 

                // Check if product exists in WordPress by BigCommerce Product ID or SKU
                $existing_product_id = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM $table_name_postmeta WHERE 
                meta_key = '_bigcommerce_id' AND meta_value = %d LIMIT 1", $bigcommerce_id));

                //sync bigcommerce images to wordpress
                // $image_data=new QEWCM_Image_Migration();
               	// $image_data->sync_bigcommerce_images_to_wordpress($bigcommerce_images_response, $existing_product_id);

               
                if ($existing_product_id) {
                    // Update existing product
                    wp_update_post(array(
                        'ID'           => $existing_product_id,
                        'post_title'   => $name,
                        'post_content' => $description,
                        'post_status'  => 'publish',
                        'post_type'    => 'product',
                    ));                   

                    // Update product meta 
                    update_post_meta($existing_product_id, '_price', $price);
                    update_post_meta($existing_product_id, '_regular_price', $price);
                    if($sale_price!='0'){
                        update_post_meta($existing_product_id, '_sale_price', $sale_price);
                    }
                    else{
                        update_post_meta($existing_product_id, '_sale_price', '');
                    }   
                    update_post_meta($existing_product_id, '_sku', $sku);
                    update_post_meta($existing_product_id, '_weight', $weight);
                    update_post_meta($existing_product_id, '_width', $width);
                    update_post_meta($existing_product_id, '_height', $height);
                    update_post_meta($existing_product_id, '_length', $depth);
                    update_post_meta($existing_product_id, '_stock', $inventory_level);                   
                    if ($inventory_level > 0) {                       
                        update_post_meta($existing_product_id, '_stock_status', 'instock');
                    } else {                       
                        update_post_meta($existing_product_id, '_stock_status', 'outofstock');
                    }
                    update_post_meta($existing_product_id, '_bigcommerce_id', $bigcommerce_id);

                    // $insertCategory= new QEWCM_Category_Migration();
                    // $insertCategory->categoryMigration();

                    $this->assignCategoryToProduct($existing_product_id,$bigcommerceCategories);

                    foreach ($bigcommerceOption as $option) { 
				    	if(!empty($option)){ 
				    		// wp_set_object_terms($existing_product_id, 'variable', 'product_type');
					    	// $this->assign_wc_product_attributes($existing_product_id,$option);
					    	// $this->assign_custom_variations_to_product($existing_product_id,$bigcommerceVariation);
					    	$variationImport = new QEWCM_Variation_migration();
                    		$variationResponse = $variationImport->createWcAttribute($existing_product_id,$bigcommerceVariation);
				    		// $this->assign_wc_product_attributes($existing_product_id,$option);
					    	// $this->assign_custom_variations_to_product($existing_product_id,$bigcommerceVariation);
				    	}
				    	else{
				    		
				    		wp_set_object_terms($existing_product_id, 'simple', 'product_type');
				    		
				    	}
				    	
				    		    	
				    }
                    

                    

                   
                    
                    // $product = wc_get_product($existing_product_id); // Get the WooCommerce product object

                    // // Assign the categories
                    // $product->set_category_ids($bigcommerce_response->categories); // Array of category IDs

                    // // Save the product with updated categories
                    // $product->save();
                    
                    echo 'Product updated: ' . $name . ' (ID: ' . $existing_product_id . ')<br>';

                }
                else {
                    // Insert new product
                    $new_product_id = wp_insert_post(array(
                        'post_title' => $name,
                        'post_content' => $description,
                        'post_status'  => 'publish',
                        'post_type'    => 'product',
                    ));
                   
                    // Insert product meta 
                    update_post_meta($new_product_id, '_price', $price);
                    update_post_meta($new_product_id, '_regular_price', $price);
                    if($sale_price!='0'){
                        update_post_meta($new_product_id, '_sale_price', $sale_price);
                    }
                    else{
                        update_post_meta($new_product_id, '_sale_price', '');
                    }
                    update_post_meta($new_product_id, '_sku', $sku);
                    update_post_meta($new_product_id, '_sku', $sku);
                    update_post_meta($new_product_id, '_weight', $weight);
                    update_post_meta($new_product_id, '_width', $width);
                    update_post_meta($new_product_id, '_height', $height);
                    update_post_meta($new_product_id, '_length', $depth);
                    update_post_meta($new_product_id, '_stock', $inventory_level);
                    if ($inventory_level > 0) {                       
                        update_post_meta($new_product_id, '_stock_status', 'instock');
                    } else {                       
                        update_post_meta($new_product_id, '_stock_status', 'outofstock');
                    }
                    update_post_meta($new_product_id, '_bigcommerce_id', $bigcommerce_id);

                    //  $insertCategory= new QEWCM_Category_Migration();
                    // $insertCategory->categoryMigration();


                    $this->assignCategoryToProduct($new_product_id,$bigcommerceCategories);

                    foreach ($bigcommerceOption as $option) {
				    	if(!empty($option)){
				    		wp_set_object_terms($existing_product_id, 'variable', 'product_type');
					    	$this->assign_wc_product_attributes($existing_product_id,$option);
					    	$this->assign_custom_variations_to_product($existing_product_id,$bigcommerceVariation);
				    		
				    	}
				    	else{
				    		
				    		wp_set_object_terms($existing_product_id, 'simple', 'product_type');
				    		
				    	}
				    	
				    		    	
				    }

                    // $variationImport = new QEWCM_Variation_migration();
                    // $variationResponse = $variationImport->createWcAttribute($new_product_id);

                    // $product = wc_get_product($new_product_id); // Get the WooCommerce product object

                    // // Assign the categories
                    // $product->set_category_ids($bigcommerce_response->categories); // Array of category IDs

                    // // Save the product with updated categories
                    // $product->save();

                    echo 'New product inserted: ' . $name . ' (ID: ' . $new_product_id . ')<br>';
                }  
                
            }
           
        } 

        		        
	}
}