<?php
/**
 * Plugin Name: Woocommerce Data Migration
 * Description: A WordPress plugin to migarte all products, customer and orders related data.
 * Version: 1.0
 * Author: AQE Digital
 */

// Exit if accessed directly.
defined('ABSPATH') || exit;

define('QEWCM_PLUGIN_FILE', plugin_dir_path(__FILE__));

// Autoload files
require_once plugin_dir_path(__FILE__) . 'includes/class-qewcm-plugin.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/class-qewcm-admin.php';


function qewcm_plugin_autoload($class) {

    if (strpos($class, 'QEWCM\\') === 0) {
        // Remove the base namespace        
        $relativeClass = str_replace('QEWCM\\', '', $class);
        
        // Convert namespace to file path
        $relativeClass = strtolower(str_replace('\\', '/class-', $relativeClass));
    
        $relativeClass = str_replace('_', '-', $relativeClass);
        // Determine the folder (api or includes) based on the namespace
       
        if (strpos($relativeClass, 'api') === 0) {      
            $file = plugin_dir_path(__FILE__) . 'includes/' . $relativeClass . '.php';
        } 
        else if(strpos($relativeClass, 'helper') === 0){
            $file = plugin_dir_path(__FILE__) . 'includes/' . $relativeClass . '.php';
        }
        else if(strpos($relativeClass, 'admin') === 0){
            $file = plugin_dir_path(__FILE__) . 'includes/' . $relativeClass . '.php';
        }
        else {
            $file = plugin_dir_path(__FILE__) . 'includes/class-' . $relativeClass . '.php';
        }
        
        if (file_exists($file)) {
            require_once $file;
        }
    }
}

spl_autoload_register('qewcm_plugin_autoload');

// Initialize the plugin
function run_wcmp_plugin() {
    $plugin = new QEWCM_Plugin();
    $plugin->run();
}
run_wcmp_plugin();