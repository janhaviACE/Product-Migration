jQuery(document).ready(function($) {
    //For insert the api related data
    $('#api_key_form').on('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

       
        var api_key = $('#api_key').val();
        var store_hash_code = $('#store_hash_code').val();
        var api_platform = $('#api_platform').val();
        
        $.ajax({
            url: ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'insertApiData',
                api_key: api_key,               
                store_hash_code: store_hash_code,
                api_platform: api_platform,
            },
            success: function(response) {
                console.log(response);
                if (response.success) {
                    $('#response-message').html('<div class="updated"><p>' + response.data + '</p></div>');
                    $('#api_key_form')[0].reset(); // Clear the form
                } else {
                    $('#response-message').html('<div class="error"><p>' + response.data + '</p></div>');
                }
            },
            error: function() {
                $('#response-message').html('<div class="error"><p>There was an error processing your request.</p></div>');
            }
        });
    });

    //When click on the migrate data button
    // $('#migrate_data_form #migrate_btn').on('click', function(event) {
    //     event.preventDefault(); // Prevent the default form submission

        
    //     var  api_platform= $('#hdn_api_platform').val();
    //     var  api_key= $('#hdn_api_key').val();
    //     var hdn_hash_code = $('#hdn_hash_code').val();
        
        
    //     $.ajax({
    //         url: ajax.ajax_url,
    //         type: 'POST',
    //         data: {
    //             action: 'getProductApiData',
    //             api_key: api_key,
    //             api_platform: api_platform,
    //             hdn_hash_code: hdn_hash_code

    //         },
    //         success: function(response) {
    //             console.log(response);
    //             if (response.success) {
    //                 $('#response-message').html('<div class="updated"><p>' + response.data + '</p></div>');
    //                 //$('#api_key_form')[0].reset(); // Clear the form
    //             } else {
    //                 $('#response-message').html('<div class="error"><p>' + response.data + '</p></div>');
    //             }
    //         },
    //         error: function() {
    //             $('#response-message').html('<div class="error"><p>There was an error processing your request.</p></div>');
    //         }
    //     });
    // });

    //When click on the migrate data button
    $('#migrate_data_form #migrate_btn').on('click', function(event) {
        event.preventDefault(); // Prevent the default form submission

        $.ajax({
            url: ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'qe_CategoryImport',           

            },
            success: function(response) {
                console.log(response);
                if (response.success) {
                    $('#response-message').html('<div class="updated"><p>' + response.data + '</p></div>');
                    //$('#api_key_form')[0].reset(); // Clear the form
                } else {
                    $('#response-message').html('<div class="error"><p>' + response.data + '</p></div>');
                }
            },
            error: function() {
                $('#response-message').html('<div class="error"><p>There was an error processing your request.</p></div>');
            }
        });
    });
    
});
